from django.conf import settings
import os

def load_forbidden_words():
    # Construye la ruta absoluta al archivo utilizando BASE_DIR
    file_path = os.path.join(settings.BASE_DIR, 'forbidden_words.txt')
    with open(file_path, 'r') as file:
        return [line.strip() for line in file]