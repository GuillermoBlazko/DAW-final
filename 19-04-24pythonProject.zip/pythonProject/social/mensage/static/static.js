
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else {
        alert("Geolocation is not supported by this browser.");
    }
}

function showPosition(position) {
    var latitude = position.coords.latitude;
    var longitude = position.coords.longitude;
    document.getElementById("latitude").value = latitude;
    document.getElementById("longitude").value = longitude;
    document.getElementById("form_post").submit();
}


document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("form_post").addEventListener("submit", function(event) {
        event.preventDefault();
        getLocation();
    });
});
/*
function getLocation() {

    console.log('entrado en el método getLocation/Mensaje');
    event.preventDefault(); // Evita el envío del formulario por defecto

        if (navigator.geolocation) {
        //Geolocation.getCurrentPosition()
            navigator.geolocation.watchPosition(showPosition);
        } else {
            alert("Geolocation is not supported by this browser.");
        }
    }

    function showPosition(position) {
        var latitude = position.coords.latitude;
        var longitude = position.coords.longitude;
        document.getElementById("latitude").value = latitude;
        document.getElementById("longitude").value = longitude;

        console.log(latitude);
        console.log(longitude);

        //envia el formulario después de validarlo
        document.getElementById("postForm").submit();
    }

document.addEventListener("DOMContentLoaded", function() {
    // Obtener el formulario
    var form = document.getElementById("postForm");

    // Escuchar el evento submit del formulario
    form.addEventListener("submit", function(event) {
        // Evita el envío del formulario por defecto
        event.preventDefault();
        // Llama a getLocation para obtener la ubicación y enviar el formulario
        getLocation();
    });
});
*/