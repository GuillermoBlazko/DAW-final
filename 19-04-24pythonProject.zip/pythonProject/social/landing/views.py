from django.shortcuts import render
from django.views import View
from django.contrib.auth import authenticate, login
from django.http import HttpResponseRedirect
from django.urls import reverse

class Index(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'index.html')


class CustomLogin(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'custom_login.html')

    def post(self, request, *args, **kwargs):
            username = request.POST.get('username')
            password = request.POST.get('password')
            user = authenticate(request, username=username, password=password)
            latitude = request.POST.get('latitude')
            longitude = request.POST.get('longitude')

            if user is not None:
                request.session['latitude'] = latitude
                request.session['longitude'] = longitude

                request.session.save()
                login(request, user)
                # Guardar la información de localización en la sesión
                print("form: ", latitude, " : ", longitude)

                print("session: ", request.session['latitude'], " : ", request.session['longitude'])
                return HttpResponseRedirect(reverse('post-list'))

