from django.urls import path
from .views import Index, CustomLogin
urlpatterns = [
   path('', Index.as_view(), name='index'),
   path('login', CustomLogin.as_view(), name="custom-login")

]