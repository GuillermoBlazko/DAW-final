
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else {
        alert("Geolocation is not supported by this browser.");
    }
}

function showPosition(position) {
    var latitude = position.coords.latitude;
    var longitude = position.coords.longitude;
    document.getElementById("latitude").value = latitude;
    document.getElementById("longitude").value = longitude;
    document.getElementById("login_form").submit();
}


document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("login_form").addEventListener("submit", function(event) {
        event.preventDefault();
        getLocation();
    });
});


/*

function getLocationAndSubmit(event) {
    event.preventDefault(); // Evita el envío del formulario por defecto

    if (navigator.geolocation) {
        // Solicitar ubicación
        navigator.geolocation.getCurrentPosition(function(position) {
            var latitude = position.coords.latitude;
            var longitude = position.coords.longitude;

            // Actualizar los campos ocultos con la latitud y longitud
            document.getElementById("latitude").value = latitude;
            document.getElementById("longitude").value = longitude;

            // Envía el formulario
            document.getElementById("login_form").submit();
        });
    } else {
        alert("Geolocation is not supported by this browser.");
    }
}



function getLocation() {
    console.log('Entrando en el método getLocation/Login');
    event.preventDefault(); // Evita el envío del formulario por defecto

    if (navigator.geolocation) {
        // Solicitar ubicación
        navigator.geolocation.getCurrentPosition(showPosition);
    } else {
        alert("Geolocation is not supported by this browser.");
    }
}

function showPosition(position) {
    var latitude = position.coords.latitude;
    var longitude = position.coords.longitude;
    document.getElementById("latitude").value = latitude;
    document.getElementById("longitude").value = longitude;

    console.log("Latitude: " + latitude + " Longitude: " + longitude);

    // Envía el formulario después de obtener la ubicación
    document.getElementById("loging_form").submit();
}



window.onload = function() {
    console.log('Entrando en el método getLocation/Login');
    // Captura la ubicación del usuario
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(position) {
            var latitude = position.coords.latitude;
            var longitude = position.coords.longitude;
            console.log (latitude + ": " +longitude)
            // Agrega la ubicación al campo oculto del formulario
            document.getElementById("latitude").value = latitude;
            document.getElementById("longitude").value = longitude;

            // Envía el formulario automáticamente
            document.getElementById("loging_form").submit();
        });
    } else {
        alert("La geolocalización no es compatible con este navegador.");
    }
};
*/