function getLocation() {

    console.log('entrado en el método getLocation');
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(showPosition);
        } else {
            alert("Geolocation is not supported by this browser.");
        }
    }

    function showPosition(position) {
        var latitude = position.coords.latitude;
        var longitude = position.coords.longitude;
        document.getElementById("latitude").value = latitude;
        document.getElementById("longitude").value = longitude;

        console.log(latitude);
        console.log(longitude);

        //envia el formulario después de validarlo
        document.getElementById("postForm").submit();
    }