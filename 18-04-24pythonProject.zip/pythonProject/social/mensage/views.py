from allauth.core.internal.http import redirect
from django.shortcuts import render
from django.views import View
from .models import Post, UserProfile
from .forms import PostForm
from django.views.generic.edit import DeleteView, UpdateView
from django.urls import reverse_lazy
from geopy.distance import geodesic


#Con esto chequeamos que el usuario es correcto, si no les manda un HTTP:403
from django.contrib.auth.mixins import UserPassesTestMixin, LoginRequiredMixin


class PostListView(LoginRequiredMixin, View):
    def get(self, request, *args, **kwargs):
        posts = Post.objects.all().order_by('-created_on')
        print(posts)
        reference_latitude = request.GET.get('latitude')
        reference_longitude = request.GET.get('longitude')
        radio = 1000
        form = PostForm()
        mensajes_filtrados = []

        for loc in posts:
            post_latitude = loc.latitude
            post_longitude = loc.longitude
            distance = geodesic((reference_latitude, reference_longitude), (post_latitude, post_longitude)).kilometers
            print("Distancia entre la ubicación de referencia y el post:", distance)
            if distance <= radio:
                mensajes_filtrados.append(loc)

        context = {
            'post_list': mensajes_filtrados,
            'form': form,

        }

        return render(request, 'post_list.html', context)

        '''

        :param request:
        :param args:
        :param kwargs:
        :return:

        reference_latitude = float(request.GET.get('latitude', 0))
        reference_longitude = float(request.GET.get('longitude', 0))

        # Definir el radio de búsqueda en kilómetros
        search_radius = 10

        # Filtrar los posts basados en la distancia desde la ubicación de referencia
        nearby_posts = Post.objects.filter(
            latitude__range=(reference_latitude - search_radius, reference_latitude + search_radius),
            longitude__range=(reference_longitude - search_radius, reference_longitude + search_radius)
        ).order_by('-created_on')

        # Crear un formulario para agregar nuevos posts
        form = PostForm()

        # Pasar los posts cercanos y el formulario al contexto
        context = {
            'post_list': nearby_posts,
            'form': form,
        }
        return render(request, 'post_list.html', context)
  '''
    def post(self, request, *args, **kwargs):
        form = PostForm(request.POST)

        if form.is_valid():
            new_post = form.save(commit=False)
            new_post.author = request.user
            new_post.latitude = request.POST.get('latitude')
            new_post.longitude = request.POST.get('longitude')
            new_post.save()
            #Esto controla que la peticion es nueva y si no te devuelve a una inicial sin mensaje
            return redirect('post-list')
        else:
            reference_latitude = float(request.POST.get('latitude', 0))
            reference_longitude = float(request.POST.get('longitude', 0))
            search_radius = 10
            all_posts = Post.objects.all()
            nearby_posts = []
            for post in all_posts:
                post_latitude = post.latitude
                post_longitude = post.longitude
                distance = geodesic((reference_latitude, reference_longitude), (post_latitude, post_longitude)).kilometers
                if distance <= search_radius:
                    nearby_posts.append(post)
            form = PostForm()

            '''
            post = Post.objects.all().order_by('-created_on', '-id')
            latitude = request.POST['latitude']
            longitude = request.POST['longitude'
            '''
            context = {
                'post_list': nearby_posts,
                'form': form,
                'latitude': request.POST.get('latitude'),
                'longitude':  request.POST.get('longitude'),
            }

            return render(request, 'post_list.html', context)


class PostDetailView(LoginRequiredMixin, View):
    def get(self, request, pk, *args, **kwargs):
        post = Post.objects.get(pk=pk)
        context = {
            'post': post,
        }
        return render(request, 'post_detail.html', context)


class PostEditView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Post
    fields = ['body']
    template_name = 'post_edit.html'

    #Redirect a la página de detalle que lo invocó usando reverse_lazy.
    def get_success_url(self):
        pk = self.kwargs['pk']
        return reverse_lazy('post-detail', kwargs={'pk': pk})

    def test_func(self):
        post = self.get_object()
        return self.request.user == post.author


class PostDeleteView( LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Post
    template_name = 'post_delete.html'
    success_url = reverse_lazy('post-list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        post = self.get_object()  # Obtener el objeto Post que se va a eliminar
        context['post'] = post  # Pasar el objeto al contexto
        return context

    def test_func(self):
        post = self.get_object()
        return self.request.user == post.author


class ProfileView(View):
    def get(self, request, pk, *args, **kwargs):
        profile = UserProfile.objects.get(pk=pk)
        user = profile.user
        post = Post.objects.filter(author=user).order_by('-created_on')
        context = {
            'user': user,
            'profile': profile,
            'posts': post,
        }
        return render(request, 'profile.html', context)


class ProfileEditView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = UserProfile
    fields = ['name', 'bio', 'birth_date', 'location', 'picture']
    template_name = 'profile_edit.html'

    #Redirect a la página de detalle que lo invocó usando reverse_lazy.
    def get_success_url(self):
        pk = self.kwargs['pk']
        return reverse_lazy('profile', kwargs={'pk': pk})

    def test_func(self):
        profile = self.get_object()
        return self.request.user == profile.user