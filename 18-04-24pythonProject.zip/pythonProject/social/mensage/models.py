from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from django.db.models.signals import post_save
from django.dispatch import receiver


class Post(models.Model):
    body = models.TextField()
    created_on = models.DateTimeField(default=timezone.now)
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    latitude = models.FloatField(blank=False, null=False, default=1)
    longitude = models.FloatField(blank=False, null=False, default=1)
    likes = models.IntegerField(default=0)


class UserProfile(models.Model):
    #One user = one profile.
    user = models.OneToOneField(User, primary_key=True, verbose_name='user',
                                related_name='profile', on_delete=models.CASCADE)
    name = models.CharField(max_length=30, blank=True, null=True)
    bio = models.TextField(max_length=500, blank=True, null=True)
    birth_date = models.DateField(null=True, blank=True)
    location = models.CharField(max_length=500, blank=True, null=True)
    global_likes = models.IntegerField(default=0)

    #Pictures en local
    picture = models.ImageField(upload_to='uploads/profile_pictures',
                                default='uploads/profile_pictures/default.png', blank=True)


    #Esto es un vestigio a eliminar: Si no en EditProfileView peta porque le pides el campo "picture".

    #Pictures en AWS: S3


    def __str__(self):
        return self.user.username


@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    instance.profile.save()


