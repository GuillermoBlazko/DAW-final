from django import forms
from .models import Post
#Control de palabras prohibidas
from .utils import load_forbidden_words


class PostForm (forms.ModelForm):
    body = forms.CharField(
        label= "",
        widget= forms.Textarea(attrs={
            'rows': '3',
            'placeholder': 'Post here...',
        })
    )

    class Meta:
        model = Post
        fields = ['body']

"""
Intento de filtro palabras malsonantes: 
    def clean_text(self):
        text = self.cleaned_data.get("text")
        forbidden_words = load_forbidden_words()
        if any(word in text for word in forbidden_words):
            raise forms.ValidationError("No se permiten palabras ofensivas.")
        return text

"""