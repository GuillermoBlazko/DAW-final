from django.urls import path
from .views import PostListView, PostDetailView, PostEditView, PostDeleteView, ProfileView, ProfileEditView

urlpatterns = [
    path('', PostListView.as_view(), name="post-list"),
    path('post/<int:pk>', PostDetailView.as_view(), name="post-detail"),
    path('post/edit/<int:pk>', PostEditView.as_view(), name="post-edit"),
    path('post/delete/<int:pk>', PostDeleteView.as_view(), name="post-delete"),
    path('profile/<int:pk>', ProfileView.as_view(), name="profile"),
    path('profile/edit/<int:pk>', ProfileEditView.as_view(), name="profile-edit"),

]



