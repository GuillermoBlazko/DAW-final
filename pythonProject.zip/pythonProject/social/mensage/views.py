from allauth.core.internal.http import redirect
from django.shortcuts import render
from django.views import View
from .models import Post, UserProfile
from .forms import PostForm
from django.views.generic.edit import DeleteView, UpdateView
from django.urls import reverse_lazy

#Con esto chequeamos que el usuario es correcto, si no les manda un 403
from django.contrib.auth.mixins import UserPassesTestMixin, LoginRequiredMixin


class PostListView( LoginRequiredMixin, View):
    def get(self, request, *args, **kwargs):
        post = Post.objects.all().order_by('-created_on')
        form = PostForm()

        context = {
            'post_list': post,
            'form': form,

        }

        return render(request, 'post_list.html', context)

    def post(self, request, *args, **kwargs):
        form = PostForm(request.POST)

        if form.is_valid():
            new_post = form.save(commit=False)
            new_post.author = request.user
            new_post.save()
            #Esto controla que la peticion es nueva y si no te devuelve a una inicial sin mensaje
            return redirect('post-list')
        else:
            post = Post.objects.all().order_by('-created_on', '-id')
            latitude = request.POST['latitude']
            longitude = request.POST['longitude']
            context = {
                'post_list': post,
                'form': form,
                'latitude': latitude,
                'longitude': longitude,
            }

            return render(request, 'post_list.html', context)


class PostDetailView(LoginRequiredMixin, View):
    def get(self, request, pk, *args, **kwargs):
        post = Post.objects.get(pk=pk)
        context = {
            'post': post,
        }
        return render(request, 'post_detail.html', context)


class PostEditView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Post
    fields = ['body']
    template_name = 'post_edit.html'

    #Redirect a la página de detalle que lo invocó usando reverse_lazy.
    def get_success_url(self):
        pk = self.kwargs['pk']
        return reverse_lazy('post-detail', kwargs={'pk': pk})

    def test_func(self):
        post = self.get_object()
        return self.request.user == post.author


class PostDeleteView( LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Post
    template_name = 'post_delete.html'
    success_url = reverse_lazy('post-list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        post = self.get_object()  # Obtener el objeto Post que se va a eliminar
        context['post'] = post  # Pasar el objeto al contexto
        return context

    def test_func(self):
        post = self.get_object()
        return self.request.user == post.author


class ProfileView(View):
    def get(self, request, pk, *args, **kwargs):
        profile = UserProfile.objects.get(pk=pk)
        user = profile.user
        post = Post.objects.filter(author=user).order_by('-created_on')

        context = {
            'user': user,
            'profile': profile,
            'posts': post,
        }

        return render(request, 'profile.html', context)


class ProfileEditView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = UserProfile
    fields = ['name', 'bio', 'birth_date', 'location', 'picture']
    template_name = 'profile_edit.html'

    #Redirect a la página de detalle que lo invocó usando reverse_lazy.
    def get_success_url(self):
        pk = self.kwargs['pk']
        return reverse_lazy('profile', kwargs={'pk': pk})

    def test_func(self):
        profile = self.get_object()
        return self.request.user == profile.user
